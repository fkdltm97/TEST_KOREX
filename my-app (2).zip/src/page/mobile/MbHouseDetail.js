//react
import React ,{useState} from 'react';

//css
import styled from "styled-components"

//component
import MainHeader from '../../component/common/MainHeader';
import SubTitle from '../../component/common/SubTitle';
import MbHouseView from '../../component/common/house/mobilecomp/MbHouseView';
import LiveModal from '../../component/common/house/LiveModal';
import ImgDetail from '../../component/common/house/ImgDetail';
import MainFooter from '../../component/common/MainFooter';
import TermService from '../../component/common/TermsOfService';
import TermPrivacy from '../../component/common/TermsOfPrivacy';
import TermLocation from '../../component/common/TermsOfLocation';

import { Mobile, PC } from "../../MediaQuery"

export default function MainPage() {
  //이용약관
  const [termservice, setTermService] = useState(false);
  const openTermService = (onOff) =>{ setTermService(onOff);}

  //개인정보처리방침
  const [termprivacy, setTermPrivacy] = useState(false);
  const openTermPrivacy = (onOff) =>{ setTermPrivacy(onOff);}

  //위치기반서비스 이용약관
  const [termlocation, setTermLocation] = useState(false);
  const openTermLocation = (onOff) =>{ setTermLocation(onOff);}

  //라이브 시청 모달
  const [live, setLive] = useState(false);
  const openLive = (onOff) =>{ setLive(onOff);}

  //분양 상세이미지 모달
  const [detailImg, setDetailImg] = useState(false);
  const openDetailImg = (onOff) =>{ setDetailImg(onOff);}

  return (
    <>
          <MainHeader rank={true}/>
          <Container>
            <SubTitle title={"분양상세"} rank={false}/>
            <LiveModal live={live} openLive={openLive}/>
            <ImgDetail detailImg={detailImg} openDetailImg={openDetailImg}/>
            <MbHouseView openLive={openLive} openDetailImg={openDetailImg}/>
          </Container>
          <TermService termservice={termservice} openTermService={openTermService}/>
          <TermPrivacy termprivacy={termprivacy} openTermPrivacy={openTermPrivacy}/>
          <TermLocation termlocation={termlocation} openTermLocation={openTermLocation}/>
          <MainFooter openTermService={openTermService} openTermPrivacy={openTermPrivacy} openTermLocation={openTermLocation}/>
    </>
  );
}

const Container = styled.div`
    width: 100%;
    min-height:calc(100vh - calc(100vw*(420/428)));
    padding-bottom:calc(100vw*(100/428));
`
