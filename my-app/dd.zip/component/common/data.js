export const term1Option = [
  { value: '', label: '이전 서비스 이용약관 보기', color: '#00B8D9', isFixed: true },
  { value: '2019년 03월 02일', label: '2019년 03월 02일', color: '#00B8D9', isFixed: true },
  { value: '2020년 03월 03일', label: '2020년 03월 02일', color: '#00B8D9', isFixed: true },
  { value: '2021년 03월 04일', label: '2021년 03월 02일', color: '#00B8D9', isFixed: true },
];
export const groupedOptions1 = [
  {
    options: term1Option,
  },
];
